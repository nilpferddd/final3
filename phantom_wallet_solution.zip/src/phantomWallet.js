/**
 * Simplified Phantom Wallet Integration
 * Based on official Phantom documentation: https://docs.phantom.com/solana/
 */

/**
 * Detects if Phantom wallet is installed
 * @returns {boolean} True if Phantom is installed
 */
export const isPhantomInstalled = () => {
  if (typeof window !== 'undefined') {
    return window?.phantom?.solana?.isPhantom || false;
  }
  return false;
};

/**
 * Gets the Phantom provider if it exists
 * @returns {Object|null} The Phantom provider or null if not found
 */
export const getPhantomProvider = () => {
  if (typeof window !== 'undefined' && window.phantom?.solana) {
    return window.phantom.solana;
  }
  return null;
};

/**
 * Connects to Phantom wallet and returns the public key
 * @returns {Promise<string>} The public key of the connected wallet
 * @throws {Error} If connection fails or is rejected
 */
export const connectPhantomWallet = async () => {
  try {
    const provider = getPhantomProvider();
    
    if (!provider) {
      window.open('https://phantom.app/', '_blank');
      throw new Error('Phantom wallet not installed. Please install it from phantom.app');
    }
    
    console.log('Requesting connection to Phantom wallet...');
    const response = await provider.connect();
    console.log('Connection successful!', response);
    
    return response.publicKey.toString();
  } catch (error) {
    console.error('Error connecting to Phantom wallet:', error);
    throw error;
  }
};

/**
 * Disconnects from Phantom wallet
 * @returns {Promise<void>}
 */
export const disconnectPhantomWallet = async () => {
  try {
    const provider = getPhantomProvider();
    
    if (provider) {
      await provider.disconnect();
      console.log('Disconnected from Phantom wallet');
    }
  } catch (error) {
    console.error('Error disconnecting from Phantom wallet:', error);
    throw error;
  }
};

/**
 * Adds a token to the Phantom wallet
 * @param {string} tokenAddress - The address of the token to add
 * @returns {Promise<void>}
 */
export const addTokenToPhantomWallet = async (tokenAddress) => {
  try {
    const provider = getPhantomProvider();
    
    if (!provider) {
      throw new Error('Phantom wallet not installed');
    }
    
    await provider.request({
      method: 'wallet_watchAsset',
      params: {
        type: 'SPL',
        options: {
          address: tokenAddress
        }
      }
    });
    
    console.log('Token added to wallet:', tokenAddress);
  } catch (error) {
    console.error('Error adding token to wallet:', error);
    throw error;
  }
};

/**
 * Sets up event listeners for Phantom wallet events
 * @param {Object} callbacks - Callback functions for different events
 * @returns {Function} Function to remove event listeners
 */
export const setupPhantomEventListeners = (callbacks = {}) => {
  const provider = getPhantomProvider();
  
  if (!provider) {
    console.error('Phantom wallet not installed');
    return () => {};
  }
  
  // Connect event
  if (callbacks.onConnect) {
    provider.on('connect', callbacks.onConnect);
  }
  
  // Disconnect event
  if (callbacks.onDisconnect) {
    provider.on('disconnect', callbacks.onDisconnect);
  }
  
  // Account change event
  if (callbacks.onAccountChange) {
    provider.on('accountChanged', callbacks.onAccountChange);
  }
  
  // Return function to remove event listeners
  return () => {
    if (callbacks.onConnect) provider.removeListener('connect', callbacks.onConnect);
    if (callbacks.onDisconnect) provider.removeListener('disconnect', callbacks.onDisconnect);
    if (callbacks.onAccountChange) provider.removeListener('accountChanged', callbacks.onAccountChange);
  };
};

/**
 * Checks if the wallet is connected
 * @returns {boolean} True if connected
 */
export const isPhantomConnected = () => {
  const provider = getPhantomProvider();
  return provider?.isConnected || false;
};

/**
 * Gets the public key of the connected wallet
 * @returns {string|null} The public key or null if not connected
 */
export const getConnectedPublicKey = () => {
  const provider = getPhantomProvider();
  return provider?.publicKey?.toString() || null;
};
